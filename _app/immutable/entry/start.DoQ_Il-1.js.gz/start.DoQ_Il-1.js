import{a as t}from"../chunks/entry.Dw-aMVQg.js";export{t as start};
