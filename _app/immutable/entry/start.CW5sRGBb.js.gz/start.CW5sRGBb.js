import{a as t}from"../chunks/entry.CQ3Qnytf.js";export{t as start};
