import{a as t}from"../chunks/entry.ClGmLapJ.js";export{t as start};
