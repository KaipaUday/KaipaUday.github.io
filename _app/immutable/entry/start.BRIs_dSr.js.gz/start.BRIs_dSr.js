import{a as t}from"../chunks/entry.DOMmpodJ.js";export{t as start};
