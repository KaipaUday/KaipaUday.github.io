# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt

# Function to simulate loading raster data (normally you would load this from a file)
def load_raster_data():
    # For demonstration, create a synthetic raster dataset
    data = np.random.rand(100, 100, 8, 8)  # A 100x100 raster with random values
    return data

# Function to process the raster data (e.g., normalize values)
def process_raster_data(data):
    # Normalize the data to range [0, 1]
    data_min = data.min()
    data_max = data.max()
    normalized_data = (data - data_min) / (data_max - data_min)
    return normalized_data

# Function to visualize the raster data
def plot_raster_data(data, title="Raster Data", channel=0):
    data=data[:,:,channel, channel]
    plt.imshow(data, cmap='viridis')
    plt.colorbar()
    plt.title(title)
    plt.show()

    # Function to visualize the raster data
def plot_raster_data_processed(data, title="Raster Data"):
    plt.imshow(data, cmap='viridis')
    plt.colorbar()
    plt.title(title)
    plt.show()

def aggregate_raster(data, aggregation_type='mean', channel=0, axis=-1):
    """
    Aggregates raster data based on the specified aggregation type.

    Parameters:
    data (numpy.ndarray): The input raster data.
    aggregation_type (str): The type of aggregation ('mean', 'sum', 'min', 'max').

    Returns:
    numpy.ndarray: Aggregated raster data.
    """
    data=data[:,:,:,channel]
    print(data.shape)
    if aggregation_type == 'mean':
        return np.mean(data, axis)
    elif aggregation_type == 'sum':
        return np.sum(data, axis)
    elif aggregation_type == 'min':
        return np.min(data, axis)
    elif aggregation_type == 'max':
        return np.max(data, axis)
    else:
        raise ValueError("Invalid aggregation type. Choose from 'mean', 'sum', 'min', 'max'.")


# Load the raster data
raster_data = load_raster_data()
# # Plot the original raster data
plot_raster_data(raster_data, title="Original Raster Data")


# Process the raster data
processed_raster_data = aggregate_raster(raster_data)

print(processed_raster_data.shape)
# Plot the processed raster data
plot_raster_data_processed(processed_raster_data, title="Processed Raster Data")
